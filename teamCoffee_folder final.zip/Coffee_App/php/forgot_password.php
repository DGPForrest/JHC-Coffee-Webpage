<html lang ="en">
<head>
    <meta charset="UTF-8">
    <meta name='viewport' content="width=device-width, initial-scale=1.0">
    
	<!--Bootstrap 5 connection-->
  	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	
    <link rel="stylesheet" href='/jrivyevj/Coffee_App/css/style.css'>
    
    <title>Forgot Password</title> 
	<link rel = "icon" href = "/jrivyevj/Coffee_App/images/logo.png" type = "image/x-icon">
    </head>
    
    <body class="fixed">
		<!-- Bootstrap script-->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
		

	<nav id="login_nav">
		<img class="hargest_circle"> 
	</nav>
		
	<main id="login">
		<container class="login">
			<h4 id="back"><a href="login.php">←Back</a></h4>
			<div id="login-box">
				<h3 id="login_header">Forgot Password</h3>
				<form action="check_forgot_password.php" method="post"> <!--Form-->
					<?php if (isset($_GET['error'])) { ?>
					<p class="error"><?php echo $_GET['error']; ?></p>
					<?php } ?>
					
					<div class="row pad"> <!--Email input-->
						<!--<div class="col-xs-12 col-sm-3"> <!--phone: take whole width, laptop/tablet: take 3 columns-->
							<!---<label>Email</label>
						</div>-->
						<div class="col-xs-12 col-sm-12"> <!--phone: take whole width, laptop/tablet: take 9 columns-->
							<span>Please enter your email below.</span>
						</div>						
					</div>
					
					<div class="row pad	email"> <!--Email input-->
						<!--<div class="col-xs-12 col-sm-3"> <!--phone: take whole width, laptop/tablet: take 3 columns-->
							<!---<label>Email</label>
						</div>-->
						<div class="col-xs-12 col-sm-12"> <!--phone: take whole width, laptop/tablet: take 9 columns-->
							<input class="input" type="email" name="email" placeholder="Email" required><br> <!--Email input-->
						</div>						
					</div>
					
					<div class="row forget_button"> <!--Button to login-->
						<div class="col-xs-12 col-sm-3 login_button" id="login_button"> <!--phone: take whole width, laptop/tablet: take 3 columns-->
							<button type="submit" class="btn btn-primary">Next</button> <!--Login button-->
						</div>
					</div>
						
				 </form>
			</div>
			
		</container>
	</main>
