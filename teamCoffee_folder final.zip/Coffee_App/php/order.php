<!--─────────────────Order page────────────────-->

<?php include("topbit.php")?>

<?php 

session_start();

if (isset($_SESSION['Email']) && isset($_SESSION['First_name'])) {

}else{

     header("Location: login.php");
	//echo "Session not found";
     exit();

}

 ?>

  <main>
    <container>
		<p>This is the final order page</p>	
	</container>
	<!--
	List of stuff to add to order page
	//Item ordered
	//Drop down checkbox for extras
	
	//Radiobuttons for size
	Pickup time and date
	Textbox for comments
	Live updating cost
	Radiobutton for payment type
	
	Once ordered, show order number


	-->
































   </main>     
<?php include("bottombit.php") ?>
