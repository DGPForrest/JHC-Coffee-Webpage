<html lang ="en">
<head>
    <meta charset="UTF-8">
    <meta name='viewport' content="width=device-width, initial-scale=1.0">
    
	<!--Bootstrap 5 connection-->
  	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	
    <link rel="stylesheet" href='/jrivyevj/Coffee_App/css/style.css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>JHC Coffee cart Websites</title> 
	<link rel = "icon" href = "/jrivyevj/Coffee_App/images/logo.png" type = "image/x-icon">
    </head>
    <script type="text/javascript" src="/jrivyevj/Coffee_App/scripts/scripts.js"></script> <!-- Including our scripting file. -->
    <body>
		<!-- Bootstrap script-->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <header>
			
		</header>

    <!----------------Navbar----------------->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
		
      <a class="navbar-brand" href="index.php">
		
		<h1 id="nav-text">Hargest Coffee CO</h1>
		    
      </a>
		
		

			



    </div>
	  
	  
	  <a class="navbar-brand" href="cart.php">
		
		<h3 id="cart-text">Cart
		<svg id="cart-icon"  xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 576 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M0 24C0 10.7 10.7 0 24 0H69.5c22 0 41.5 12.8 50.6 32h411c26.3 0 45.5 25 38.6 50.4l-41 152.3c-8.5 31.4-37 53.3-69.5 53.3H170.7l5.4 28.5c2.2 11.3 12.1 19.5 23.6 19.5H488c13.3 0 24 10.7 24 24s-10.7 24-24 24H199.7c-34.6 0-64.3-24.6-70.7-58.5L77.4 54.5c-.7-3.8-4-6.5-7.9-6.5H24C10.7 48 0 37.3 0 24zM128 464a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm336-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"/></svg>
			</h3>
      </a>


	  
  </nav>
		 	<span class="text-light" id="logout"><a style="color: white;" href="logout.php">Logout</a></span>




      
