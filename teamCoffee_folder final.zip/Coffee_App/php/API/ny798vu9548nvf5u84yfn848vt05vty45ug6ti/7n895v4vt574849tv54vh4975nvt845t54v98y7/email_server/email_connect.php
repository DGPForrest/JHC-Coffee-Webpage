<?php
	// Database server information
	$servername = "localhost";
	// Database username
	$username = "teamCoffee";
	// Database password
	$password = "jhc2023";
	// Database name
	$dbname = "teamCoffee_JHC_Coffee";

	// Create a new MySQLi database connection using the provided server, username, password, and database name.
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check if the database connection was successful.
	if ($conn->connect_error) {
		// If there's an error in the connection, display an error message and terminate the script.
		die("Error Connecting to Database: " . $conn->connect_error);
	}
?>