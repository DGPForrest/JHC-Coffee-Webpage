<?php
	// Include the email_connect.php file to establish a database connection.
	require_once 'email_connect.php';

	// Define a SQL query to select all records from the 'To_send' table where 'Sent' is set to 0 (unsent messages).
	$sql = "SELECT *
		FROM To_send WHERE Sent=0";

	// Execute the SQL query and store the result in the $result variable.
	$result = $conn->query($sql);

	// Check if the query was executed successfully.
	if ($result) {
      	// Check if there are rows in the result set.
		if ($result->num_rows > 0) {  
			// Fetch the first row from the result.
			$row = $result->fetch_assoc();

			// Extract the 'ID' field from the row.
			$ID = $row["ID"];

			// Output the message information in a custom format.
			echo "[";
			echo $row["ID"];
			echo "]{";
			echo $row["Contact_info"];
			echo "}(";
			echo $row["Type"];
			echo ")/";
			echo $row["Title"];
			echo "=;";
			echo $row["Message"];
			echo ":";

			// Define an SQL query to update the 'Sent' status to 1 for the current message.
			$sql = "UPDATE To_send SET Sent=1 WHERE id=$ID";

			// Execute the update query to mark the message as sent.
			if ($conn->query($sql) === TRUE) {
  				// The update was successful.
			} else {
  				// An error occurred during the update process.
			}
		}
	}
?>