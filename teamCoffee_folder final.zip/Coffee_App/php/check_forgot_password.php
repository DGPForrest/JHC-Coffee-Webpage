<?php 

include "connect.php";
session_start(); // Start a new session or resume the existing session.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(EALL);

if (isset($_POST['email'])) {

    function validate($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    // Retrieve and validate the user's email from the POST request.
    $email = validate($_POST['email']);
	
    if (empty($email)) {
        // Redirect to the login page with an error message if the email is empty.
        header("Location: login.php?error=Email is required");
        exit();
    } else {
        // Check if the provided email exists in the database.
        $sql = "SELECT * FROM Users WHERE Email='$email'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);

            // Generate a verification code.
            $vcode = rand(100000, 999999);
            
            // Insert the verification code into the 'To_send' table to be sent via email.
            $sql = "INSERT INTO To_send (Contact_info, Type, Title, Message, Sent)
                    VALUES ('$email', 'email', 'Verification Code: $vcode', 'Your verification code is $vcode', '0')";

            if ($conn->query($sql) === TRUE) {
                echo "Email sent"; // You can remove this line (used for debugging).
                // Store the verification code and email in session variables for further verification.
                $_SESSION['verification_code'] = $vcode;
                $_SESSION['verification_email'] = $email;
                header("Location: verify.php"); // Redirect to the verification page.
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }

            exit();
        } else if (mysqli_num_rows($result) === 0) {
            // Email does not exist, prompt the user to create an account.
            header("Location: forgot_password.php?error=Email does not exist. Please make an account.");
            exit();
        } else {
            // Multiple accounts with the same email exist; suggest the user contact support.
            header("Location: forgot_password.php?error=Multiple accounts with this email already exist. Please contact support");
            exit();
        }
    }
} else {
    // If the 'email' parameter is not set, redirect to the index page.
    header("Location: index.php");
    exit();
}
?>
