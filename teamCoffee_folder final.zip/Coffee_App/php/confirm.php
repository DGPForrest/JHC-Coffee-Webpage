<?php 

include "connect.php";
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['id'])) {

    function validate($data){

       $data = trim($data);

       $data = stripslashes($data);

       $data = htmlspecialchars($data);

       return $data;

    }


    $id = validate($_GET['id']);
	
	$user_email = $_SESSION['Email'];
	
	
		
    if (empty($id)) {

        header("Location: orders_display.php?error=There was an error");

        exit();

    }else{
		



        $sql = "SELECT * FROM Current_orders WHERE ID='$id'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);
				
			$order = $row["Order_state"];
			
			$user_ID = $row["User_ID"];
			$time_ordered = $row["Pick_up_time"];
			$date_ordered = $row["Pick_up_date"];
			$product = $row["Products"];
			$extras = $row["Extras"];
			$comment = $row["Comments"];
			$size = $row["Size"];
			$quantity = $row["Quantity"];
			$total_cost = $row["Total_cost"];
			$order_number = $row["ID"];
			$barista = $user_email;
			
			
			echo $time_ordered;
			
			
			
			$sql = "UPDATE Current_orders SET Order_state=3 WHERE ID=$id";

					if ($conn->query($sql) === TRUE) {
						
						$sql = "INSERT INTO Past_orders (User_ID, Time_ordered, Date_ordered, Product, Extras, Comment, Size, Quantity, Total_cost, Order_number, Barista)
						VALUES ('$user_ID', '$time_ordered', '$date_ordered', '$product', '$extras', '$comment', '$size', '$quantity', '$total_cost', '$order_number', '$barista')";

						if ($conn->query($sql) === TRUE) {
							header("Location: orders_display.php?error=Success");

						} else {
							echo "Error: " . $sql . "<br>" . $conn->error;
						}
						
						
						
						
						
  						
						
					} else {
  						header("Location: orders_display.php?error=Update error occurded");

			
		
            			exit();		
					}
			
			
			
			
        }else if (mysqli_num_rows($result) === 0){

            header("Location: orders_display.php?error=This ID does not exist");

			
		
            exit();		
		    }else {
           header("Location: orders_display.php?error=There was an error");

			
		
            exit();

        }

    }

}else{

    header("Location: index.php");

    exit();

}

