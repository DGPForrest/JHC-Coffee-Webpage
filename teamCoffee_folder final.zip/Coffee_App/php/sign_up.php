<html lang ="en">
<head>
    <meta charset="UTF-8">
    <meta name='viewport' content="width=device-width, initial-scale=1.0">
    
	<!--Bootstrap 5 connection-->
  	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	
    <link rel="stylesheet" href='/jrivyevj/Coffee_App/css/style.css'>
    
    <title>Sign Up</title> 
	<link rel = "icon" href = "/jrivyevj/Coffee_App/images/logo.png" type = "image/x-icon">
    </head>
    
    <body class="fixed">
		<!-- Bootstrap script-->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
		


	<main id="signup">
		<container class="login">

			<div id="signup-box">
				<h3 id="login_header">Sign up</h3>
				<form action="check_sign_up.php" method="post">
					<?php if (isset($_GET['error'])) { ?>
					<p class="error"><?php echo $_GET['error']; ?></p>
					<?php } ?>
					
					<div class="row pad	fname"> <!--Email input-->
						<div class="col-xs-12 col-sm-12"> <!--phone: take whole width, laptop/tablet: take 9 columns-->
							<input class="input" type="text" name="fname" placeholder="First Name" required maxlength="100"><br>
						</div>						
					</div>
					
					<div class="row lname"> <!--Password input-->
						<div class="col-xs-12 col-sm-12"> <!--phone: take whole width, laptop/tablet: take 9 columns-->
							<input class="input" type="text" name="lname" placeholder="Last Name" required  maxlength="100"><br> 
						</div>
					</div>
					
					<div class="row pad	email"> <!--Email input-->
						<div class="col-xs-12 col-sm-12"> <!--phone: take whole width, laptop/tablet: take 9 columns-->
							<input class="input" type="email" name="email" placeholder="School Email" required  maxlength="100"><br>
						</div>						
					</div>
					
					<div class="row confirm_email"> <!--Password input-->
						<div class="col-xs-12 col-sm-12"> <!--phone: take whole width, laptop/tablet: take 9 columns-->
							<input class="input" type="email" name="confirm_email" placeholder="Confirm Email" required  maxlength="100"><br> 
						</div>
					</div>
					
					<div class="row pad	password"> <!--Email input-->
						<div class="col-xs-12 col-sm-12"> <!--phone: take whole width, laptop/tablet: take 9 columns-->
							<input class="input" type="text" name="password" placeholder="Password" required  maxlength="100"><br>
						</div>						
					</div>
					
					<div class="row confirm_password"> <!--Password input-->
						<div class="col-xs-12 col-sm-12"> <!--phone: take whole width, laptop/tablet: take 9 columns-->
							<input class="input"type="text" name="confirm_password" placeholder="Confirm Password" required  maxlength="100"><br> 
						</div>
					</div>
					<div class="row login_button"> <!--Button to login-->
						<div class="col-xs-12 col-sm-9"> <!--phone: take whole width, laptop/tablet: take 8 columns-->
							<span>Have an account? Login  <a href="login.php">here</a></span>
						</div>
						<div class="col-xs-12 col-sm-3 login_button" id="login_button"> <!--phone: take whole width, laptop/tablet: take 3 columns-->
							<button type="submit" class="btn btn-primary">Sign Up</button> <!--Login button-->
						</div>
					</div>
						
				 </form>
			</div>
			
		</container>
	</main>
