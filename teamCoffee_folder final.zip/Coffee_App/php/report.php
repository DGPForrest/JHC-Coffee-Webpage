<!-- This section includes the common header from 'topbit.php' -->
<?php include("topbit.php")?>

<?php 
// Start a PHP session to manage user authentication.
session_start();

// Check if the 'Email' and 'First_name' session variables exist, indicating a logged-in user.
if (isset($_SESSION['Email']) && isset($_SESSION['First_name'])) {
    // Check if the 'Admin' session variable exists, indicating an admin user.
    if (isset($_SESSION['Admin'])){
    ?>
    <!-- Display navigation links for admin users. -->
    <div class="links">
        <form action="orders_display.php">
            <input type="submit" class="btn btn-primary" value="View current orders" />
        </form>
        <form action="index.php">
            <input type="submit" class="btn btn-primary" value="Order page" />
        </form>
        <form action="product.php">
            <input type="submit" class="btn btn-primary" value="Product management" />
        </form>
    </div>
    <?php
    } else {
        // If the user is not an admin, redirect them to the index page.
        header("Location: index.php");
    }
} else {
     // If the session variables are not set, redirect the user to the login page and exit the script.
     header("Location: login.php");
     //echo "Session not found";
     exit();
}
?>

<!-- Set the title of the page to "Report." -->
<title>Report</title>

<main>
    <container>
        <p>This is the report page. Orders are sorted by when they were made.</p>
    </container>

    <?php
    // Include the database connection file 'connect.php'.
    require_once 'connect.php';
    // Define an SQL query to select past orders and order them by Order_number in descending order.
    $sql = "SELECT * FROM Past_orders Po ORDER BY Order_number DESC";

    // Execute the SQL query.
    $result = $conn->query($sql);
    
    // Output a container div with an id for the report data.
    echo '<div id="field">';
    if($result){
        if ($result->num_rows > 0) {  
            while($row = $result->fetch_assoc()){
                $ID = $row["ID"];
                //echo $url;

                // Output order details for each order in a div with class "report."
                echo '<div class="report">';
                echo '<p class="Order_number">Order number: ' . $row["Order_number"] . '</p>';
                echo '<p class="User_ID">User ID: ' . $row["User_ID"] . '</p>';
                echo '<p class="Time_ordered">Ordered time: ' . $row["Time_ordered"] . '</p>';
                echo '<p class="Date_ordered">Ordered date: ' . $row["Date_ordered"] . '</p>';
                echo '<p class="Rproduct">Product ordered: ' . $row["Product"] . '</p>';
                echo '<p class="Extras">Extras: ' . $row["Extras"] . '</p>';
                echo '<p class="Comment">Additional information: ' . $row["Comment"] . '</p>';
                echo '<p class="Size">Size: ' . $row["Size"] . '</p>';
                echo '<p class="rquantity">Quantity: ' . $row["Quantity"] . '</p>';
                echo '<p class="Total_cost">Price: $' . $row["Total_cost"] . '</p>';
                echo '<p class="Barista">Server: ' . $row["Barista"] . '</p>';
                echo '</div>';
            }
        }
    }
    // Close the container div for report data.
    echo '</div>';
    ?>
</main>

<!-- Include the common footer from 'bottombit.php' -->
<?php include("bottombit.php") ?>