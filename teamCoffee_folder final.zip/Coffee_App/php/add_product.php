<!-- This section of HTML is the "Add Product" page. -->

<?php include("topbit.php")?>

<?php 
// Start a PHP session to manage user authentication.
session_start();

// Check if both the 'Email' and 'First_name' session variables are set, indicating a logged-in user.
if (isset($_SESSION['Email']) && isset($_SESSION['First_name'])) {
    // Check if the 'Admin' session variable is set, indicating an admin user.
    if (isset($_SESSION['Admin'])){
    ?>
    <!-- If the user is an admin, display navigation links to manage orders, return to the order page, and manage products. -->
    <div class="links">
        <form action="orders_display.php">
            <input type="submit" class="btn btn-primary" value="View current orders" />
        </form>
        <form action="index.php">
            <input type="submit" class="btn btn-primary" value="Order page" />
        </form>
        <form action="product.php">
            <input type="submit" class="btn btn-primary" value="Product management" />
        </form>
    </div>
    <?php
    } else {
        // If the user is not an admin, redirect them to the index page.
        header("Location: index.php");
    }
} else {
    // If the session variables are not set, redirect the user to the login page and exit the script.
    header("Location: login.php");
    exit();
}
?>

<!-- Set the title of the page to "Add Product." -->
<title>Add Product</title>

<!-- Container for content. -->
<container>
    <p>This is the add product page</p>
</container>

<!-- Main content section for adding a product. -->
<main class="add_product_page">
    <form action="check_add_product.php" method="post" class="add_product_form">
        <?php if (isset($_GET['error'])) { ?>
        <!-- Display an error message if the 'error' query parameter is present in the URL. -->
        <p class="error"><?php echo $_GET['error']; ?></p>
        <?php } ?>
        
        <div class="row pad name"> <!-- Product name input -->
            <div class="col-xs-12 col-sm-6"> <!-- Phone: take whole width, Laptop/Tablet: take 9 columns -->
                <input class="input" type="text" name="name" placeholder="Product Name" required maxlength="100"><br>
            </div>
        </div>
        
        <div class="row Pdescription"> <!-- Product description input -->
            <div class="col-xs-12 col-sm-6"> <!-- Phone: take whole width, Laptop/Tablet: take 9 columns -->
                <input class="input" type="text" name="description" placeholder="Description" required  maxlength="255"><br>
            </div>
        </div>
        
        <div class="row pad type"> <!-- Product type selection -->
            <div class="col-xs-12 col-sm-6"> <!-- Phone: take whole width, Laptop/Tablet: take 9 columns -->
                <label for="type">Choose what type of product it is:</label>
                <select name="type" id="type">
                    <option value="1">Main</option>
                    <option value="2">Extra</option>
                </select>
            </div>
        </div>
        
        <div class="row dollars"> <!-- Product price input (dollars) -->
            <div class="col-xs-12 col-sm-6"> <!-- Phone: take whole width, Laptop/Tablet: take 9 columns -->
                <input class="input" type="number" name="dollars" placeholder="Dollars" value="" min="0" max="10000" step="1" required><br>
            </div>
        </div>
        
        <div class="row pad cents"> <!-- Product price input (cents) -->
            <div class="col-xs-12 col-sm-6"> <!-- Phone: take whole width, Laptop/Tablet: take 9 columns -->
                <input class="input" type="number" name="cents" placeholder="Cents" required  value="" min="00" max="99" step="1"><br>
            </div>
        </div>
        
        <div class="row login_button"> <!-- Submit button for adding a product -->
            <div class="col-xs-12 col-sm-3 login_button" id="add_product_button"> <!-- Phone: take whole width, Laptop/Tablet: take 3 columns -->
                <button type="submit" class="btn btn-primary">Add Product</button> <!-- Login button -->
            </div>
        </div>
    </form>
</main>

<?php include("bottombit.php") ?>