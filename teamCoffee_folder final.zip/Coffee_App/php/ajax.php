<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

//Including Database configuration file.
include "connect.php";

//Getting value of "search" variable from "script.js".
if (isset($_POST['email'])) {
//Search box value assigning to $Name variable.
   $email = $_POST['email'];
if ($email == ""){
	
}else{
$Query = "SELECT * FROM Users WHERE Email='$email' AND Admin_Rights!='0'";
	$count = 0;
//Search query.
   
//Query execution
    $ExecQuery = MySQLi_query($conn, $Query);
//Creating unordered list to display result.
   //Fetching result from database.
    while ($Result = MySQLi_fetch_array($ExecQuery)) {
       ?>
   <!-- Creating unordered list items.
        Calling javascript function named as "fill" found in "script.js" file.
        By passing fetched result as parameter. -->
   <!-- Assigning searched result in "Search box" in "search.php" file. -->
		<?php 

		$count = 1;

		?>
		<div class="col-xs-12 col-sm-12 admin_login"> <!--phone: take whole width, laptop/tablet: take 3 columns-->
			<input type="checkbox" id="chkadmin" name="Admin" value="0" checked>
			<label for="admin" style="margin-left: 0.5rem;">I am logging in as a Barista/Admin</label>
		</div>
		<?php

		
		
		
		
		
		
		?>
   </li>
   <!-- Below php code is just for closing parenthesis. Don't be confused. -->
   <?php
}
	
	

}}else{
}
?>



