<!--─────────────────Order page────────────────-->

<?php include("topbit.php")?>

<?php 

session_start();

if (isset($_SESSION['Email']) && isset($_SESSION['First_name'])) {
	if (isset($_SESSION['Barista'])) {
	?>
	<form action="index.php">
    	<input type="submit" class="btn btn-primary" value="Order page" />
	</form>
	
	<?php
	}elseif (isset($_SESSION['Admin'])) {
	?>
<div class="links">
	<form action="index.php">
    	<input type="submit" class="btn btn-primary" value="Order page" />
	</form>
	<form action="report.php">
    	<input type="submit" class="btn btn-primary" value="View past orders" />
	</form>
	<form action="product.php">
    	<input type="submit" class="btn btn-primary" value="Product management" />
	</form>
</div>
	<?php
	}
}else{

     header("Location: login.php");
	//echo "Session not found";
     exit();

}

 ?>

  <main>
    <container>
		<p>This page will display all the orders currently being made</p>	
	</container>



 
	<?php    

		
		
		
		

		
		
		
		
		
		
	require_once 'connect.php';
	date_default_timezone_set("Pacific/Auckland");
	$date = date("Y-m-d");   
	$sql = "SELECT *
		FROM Current_orders WHERE Order_state = 0 AND Pick_up_date = '$date'";


	$result = $conn->query($sql);
		
	echo'<div id="to_make">';
	echo '<h3 class="co_label">To make:</h3>';
	if($result){
      	if ($result->num_rows> 0) {  
			while($row = $result->fetch_assoc()){
				$ID = $row["ID"];
				//echo $url;

				
				$pay = "Not defined";
				if ($row["Payment_state"] == "0"){
					$pay = "Not paid";
				}else if ($row["Payment_state"] == "1"){
					$pay = "Paid";
				}
				
				
				$order = "Not defined";
				if ($row["Order_state"] == "0"){
					$order = "To Make";
				}else if ($row["Order_state"] == "1"){
					$order = "Making";
				}else if ($row["Order_state"] == "2"){
					$order = "Ready";
				}
					
					

					echo '<div class="order">';
						echo '<p class="name">Name: ' . $row["Name"] . '</p>';
						echo '<p class="user_id">Order ID: ' . $row["User_ID"] . '</p>';
						echo '<p class="rproduct">Product ordered: ' . $row["Products"] . '</p>';
						echo '<p class="extras">Extras: ' . $row["Extras"] . '</p>';
						echo '<p class="comment">Additional infomation: ' . $row["Comments"] . '</p>';
						echo '<p class="size">Size: ' . $row["Size"] . '</p>';
						echo '<p class="oquantity">Quantity: ' . $row["Quantity"] . '</p>';
						echo '<p class="total_cost">Price: $' . $row["Total_cost"] . '</p>';
						//echo '<p class="payment_state">Payment State: ' . $pay . '</p>';
						echo '<p class="state">Pick up time: ' . $row["Pick_up_time"] . '</p>';
						echo '<form action="making.php?id=' . $ID . '" method="post">';
    					echo '<button type="submit" class="btn btn-primary">Making</button>';
						echo '</form>';
						
							
				
	 				echo '</div>';
					

				}
		}
	}
	echo'</div>';
	  
	  
	  
		$sql = "SELECT *
		FROM Current_orders WHERE Order_state = 1 AND Pick_up_date = '$date'";


	$result = $conn->query($sql);
		
	echo'<div id="making">';
	echo '<h3 class="co_label">Making:</h3>';
	if($result){
      	if ($result->num_rows> 0) {  
			while($row = $result->fetch_assoc()){
				$ID = $row["ID"];
				//echo $url;
				

				$pay = "Not defined";
				if ($row["Payment_state"] == "0"){
					$pay = "Not paid";
				}else if ($row["Payment_state"] == "1"){
					$pay = "Paid";
				}
				
				
				$order = "Not defined";
				if ($row["Order_state"] == "0"){
					$order = "To Make";
				}else if ($row["Order_state"] == "1"){
					$order = "Making";
				}else if ($row["Order_state"] == "2"){
					$order = "Ready";
				}
				
				
					
					

					echo '<div class="order">';
						echo '<p class="name">Name: ' . $row["Name"] . '</p>';
						echo '<p class="user_id">Order ID: ' . $row["User_ID"] . '</p>';
						echo '<p class="rproduct">Product ordered: ' . $row["Products"] . '</p>';
						echo '<p class="extras">Extras: ' . $row["Extras"] . '</p>';
						echo '<p class="comment">Additional infomation: ' . $row["Comments"] . '</p>';
						echo '<p class="size">Size: ' . $row["Size"] . '</p>';
						echo '<p class="oquantity">Quantity: ' . $row["Quantity"] . '</p>';
						echo '<p class="total_cost">Price: $' . $row["Total_cost"] . '</p>';
						//echo '<p class="payment_state">Payment State: ' . $pay . '</p>';
						echo '<p class="state">Pick up time: ' . $row["Pick_up_time"] . '</p>';
						echo '<form action="move_back.php?id=' . $ID . '" method="post">';
    					echo '<button type="submit" class="btn btn-primary">Move back</button>';
						echo '</form>';
						echo '<form action="ready.php?id=' . $ID . '" method="post">';
    					echo '<button type="submit" class="btn btn-primary">Ready</button>';
						echo '</form>';
	 				echo '</div>';
					

				}
		}
	}
	echo'</div>';

	  
	  
	  
	  	$sql = "SELECT *
		FROM Current_orders WHERE Order_state = 2 AND Pick_up_date = '$date'";


	$result = $conn->query($sql);
		
	echo'<div id="ready">';	
	echo '<h3 class="co_label">Ready for pick up:</h3>';
	if($result){
      	if ($result->num_rows> 0) {  
			while($row = $result->fetch_assoc()){
				$ID = $row["ID"];
				//echo $url;
				

				
				
				$pay = "Not defined";
				if ($row["Payment_state"] == "0"){
					$pay = "Not paid";
				}else if ($row["Payment_state"] == "1"){
					$pay = "Paid";
				}
				
				
				$order = "Not defined";
				if ($row["Order_state"] == "0"){
					$order = "To Make";
				}else if ($row["Order_state"] == "1"){
					$order = "Making";
				}else if ($row["Order_state"] == "2"){
					$order = "Ready";
				}
					
					

					echo '<div class="order">';
						echo '<p class="name">Name: ' . $row["Name"] . '</p>';
						echo '<p class="user_id">Order ID: ' . $row["User_ID"] . '</p>';
						echo '<p class="rproduct">Product ordered: ' . $row["Products"] . '</p>';
						echo '<p class="extras">Extras: ' . $row["Extras"] . '</p>';
						echo '<p class="comment">Additional infomation: ' . $row["Comments"] . '</p>';
						echo '<p class="size">Size: ' . $row["Size"] . '</p>';
						echo '<p class="oquantity">Quantity: ' . $row["Quantity"] . '</p>';
						echo '<p class="total_cost">Price: $' . $row["Total_cost"] . '</p>';
						//echo '<p class="payment_state">Payment State: ' . $pay . '</p>';
						echo '<p class="state">Pick up time: ' . $row["Pick_up_time"] . '</p>';
						echo '<form action="move_back.php?id=' . $ID . '" method="post">';
    					echo '<button type="submit" class="btn btn-primary">Move back</button>';
						echo '</form>';
						echo '<form action="confirm.php?id=' . $ID . '" method="post">';
    					echo '<button type="submit" class="btn btn-primary">Confirm Order</button>';
						echo '</form>';
	 				echo '</div>';
					

				}
		}
	}
	echo'</div>';

	?>    






























   </main>     
<?php include("bottombit.php") ?>
