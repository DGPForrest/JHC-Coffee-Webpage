<?php 

session_start(); // Start a new session

include "connect.php"; // Include the connection to your database

if (1==1) { // A placeholder condition, you might want to replace this with a more meaningful check

    function validate($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }
    
    // Validate and retrieve data from the form
    $name = validate($_POST['name']);
    $description = validate($_POST['description']);
    $type = validate($_POST['type']);
    $dollars = validate($_POST['dollars']);
    $cents = validate($_POST['cents']);
    
    // Insert the product data into the database
    $sql = "INSERT INTO Products (Name, Description, Type, Dollars, Cents)
            VALUES ('$name', '$description', '$type', '$dollars', '$cents')";

    // Check if the insertion was successful
    if ($conn->query($sql) === TRUE) {
        echo "Added product";
        header("Location: product.php?error=Product added"); // Redirect with a success message
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        // Handle the error, you may want to redirect with an error message here
    }
    
    exit();
} else {
    echo "Something broke";
    header("Location: index.php"); // Handle the case where the condition is not met
    exit();
}
?>
