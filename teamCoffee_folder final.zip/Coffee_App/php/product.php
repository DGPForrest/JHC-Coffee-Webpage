<!-- Include the common header from 'topbit.php' -->
<?php include("topbit.php")?>

<?php 
// Start a PHP session for user authentication.
session_start();

// Check if 'Email' and 'First_name' session variables exist, indicating a logged-in user.
if (isset($_SESSION['Email']) && isset($_SESSION['First_name'])) {
    // Check if the 'Admin' session variable exists, indicating an admin user.
    if (isset($_SESSION['Admin'])){
    ?>
    <!-- Display navigation links for admin users. -->
    <div class="links">
        <form action="orders_display.php">
            <input type="submit" class="btn btn-primary" value="View current orders" />
        </form>
        <form action="index.php">
            <input type="submit" class="btn btn-primary" value="Order page" />
        </form>
        <form action="add_product.php">
            <input type="submit" class="btn btn-primary" value="Add product" />
        </form>
    </div>
    <?php
    } else {
        // If the user is not an admin, redirect them to the index page.
        header("Location: index.php");
    }
} else {
     // If the session variables are not set, redirect the user to the login page and exit the script.
     header("Location: login.php");
     //echo "Session not found";
     exit();
}
?>

<!-- Set the title of the page to "Products." -->
<title>Products</title>

<main>
    <container>
        <p>This is the product management page</p>
    </container>

    <?php if (isset($_GET['error'])) { ?>
        <p class="error"><?php echo $_GET['error']; ?></p>
    <?php } ?>

    <?php
    // Include the database connection file 'connect.php'.
    require_once 'connect.php';

    // SQL query to select all products from the 'Products' table.
    $sql = "SELECT * FROM Products";

    // Execute the SQL query.
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $ID = $row["ID"];
                //echo $url;

                // Try to handle any exception when parsing the 'Cents' column.
                try {
                    $cents = $row["Cents"];
                    if ($cents == "0") {
                        $cents = "00";	
                    }
                } catch (Exception $error) {
                    $cents = "00";
                }

                // Set the 'Type' based on the value (1 or 2).
                $type = $row["Type"];
                if ($type === "1") {
                    $type = "Main";	
                } else {
                    $type = "Extra";
                }

                // Output product details in a div with class "product."
                echo '<div class="product">';
                echo '<h2 class="PName">' . $row["Name"] . '</h2>';	
                echo '<p class="Description">' . $row["Description"] . '</p>';
                echo '<p class="Type">' . $type . '</p>';
                echo '<div class="price-box">';
                echo '<h3 class="Price">$' . $row["Dollars"] . '.' . $cents . '</h3>';	
                echo '<form action="delete_product.php?id=' . $row["ID"] . '" id="delete_cart" method="post">';
                echo '<input type="text" id="Delete_product" name="Delete_product" value="' . $row["ID"] . '" style="visibility: hidden; width: 1px; height: 1px;">';
                echo '<input type="submit" onclick="clicked(event)" class="buynow btn btn-primary" id="buynow" value="Delete product"/>';
                echo '</form>';	
                echo '</div>';
                echo '</div>';
            }
        }
    }
    echo '</div>';
    ?>
</main>

<!-- JavaScript function to ask for confirmation before deleting a product. -->
<script>
function clicked(e)
{
    if (!confirm('Are you sure you wish to delete this?')) {
        e.preventDefault();
    }
}
</script>

<!-- Include the common footer from 'bottombit.php' -->
<?php include("bottombit.php") ?>
