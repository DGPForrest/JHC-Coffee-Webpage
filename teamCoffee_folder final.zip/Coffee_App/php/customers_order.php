<?php 

session_start();

if (isset($_SESSION['Email']) && isset($_SESSION['First_name'])) {

}else{

     header("Location: login.php");
	//echo "Session not found";
     exit();

}

 ?>