<?php 
include "connect.php"; // Include the database connection file.
session_start(); // Start the session to access session variables.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_POST['vcode'])) {
    // Retrieve stored verification code and email from the session.
    $vcode = $_SESSION['verification_code'];
    $vemail = $_SESSION['verification_email'];

    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $uvcode = validate($_POST['vcode']); // Get and validate the entered verification code.

    if ($vcode == $uvcode) {
        // If entered code matches the stored code, redirect to the password change page.
        echo "Codes match"; // You can remove this line (used for debugging).
        header("Location: change_pass.php");
    } else {
        // If codes do not match, redirect to the verification page with an error message.
        echo "Codes do not match"; // You can remove this line (used for debugging).
        header("Location: verify.php?error=Incorrect code");
    }
} else {
    // Redirect to the index page if there's no verification code provided.
    header("Location: index.php");
    exit();
}
?>
