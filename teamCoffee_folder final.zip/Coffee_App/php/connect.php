<?php
$servername = "localhost"; // Database server hostname (usually 'localhost' when the database is on the same server)
$username = "teamCoffee";   // Database username
$password = "jhc2023";     // Database password
$dbname = "teamCoffee_JHC_Coffee";  // Database name

// Create a new MySQLi (MySQL Improved) database connection object
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    // If the connection fails, display an error message and terminate the script
    die("Error Connecting to Database: " . $conn->connect_error);
}
?>
