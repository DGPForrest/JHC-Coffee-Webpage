<?php
// Include the database connection file
include "connect.php";

// Define a function to validate data by removing unwanted characters and making it safe
function validate($data){
    $data = trim($data);  // Remove leading and trailing whitespaces
    $data = stripslashes($data);  // Remove slashes
    $data = htmlspecialchars($data);  // Convert special characters to their HTML entities
    return $data;
}

// Retrieve and validate the 'Delete_product' ID from the HTTP POST request
$id = validate($_POST['Delete_product']);

// Construct a SQL query to delete a product from the 'Products' table where the ID matches
$sql = "DELETE FROM Products WHERE ID=$id";
echo $id;  // Display the ID to check

// Execute the SQL query using the database connection
if (mysqli_query($conn, $sql)) {
  	echo "Record deleted successfully";  // Display a success message
    // Redirect the user to the 'product.php' page with a success message
	header("Location: product.php?error=Item successfully deleted");
} else {
    // If an error occurs during deletion, display an error message along with specific error details
    echo "Error deleting record: " . mysqli_error($conn);
}
?>