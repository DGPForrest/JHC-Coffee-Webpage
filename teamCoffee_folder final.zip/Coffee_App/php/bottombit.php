  <div class="wrapper">  
    <footer class="bg-dark text-center text-lg-start" id="footer">
    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
  <!-- Copyright -->
      <a class="text-light dodgey-center" href="https://www.youtube.com/watch?v=dQw4w9WgXcQ">© 2023 James Hargest College</a>
		<span class="text-light"><a style="float: right; color: white;" href="logout.php">Logout</a></span>
    </div>
   
  </footer>
         
        
  </div> <!-- / wrapper -->
    
            
</body>    

















