<?php 
session_start(); // Start a new session or resume the existing session.
include "connect.php"; // Include the database connection file.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_POST['email']) && isset($_POST['password'])) {

    function validate($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    // Retrieve and validate user login data from the POST request.
    $email = validate($_POST['email']);
    $pass = validate($_POST['password']);
	
    $id = $_GET["id"]; // You're getting an 'id' query parameter, but it's not used in this script.

    if (empty($email)) {
        header("Location: login.php?error=Email is required");
        exit();
    } else if (empty($pass)) {
        header("Location: login.php?error=Password is required");
        exit();
    } else {
        // Check if the provided email exists in the database.
        $sql = "SELECT * FROM Users WHERE Email='$email'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);

            if ($row['Email'] === $email && password_verify($pass, $row['Password'])) {
                // Successfully logged in. Set session variables.
                echo "Logged in!"; // You can remove this line (used for debugging).
                $_SESSION['Email'] = $row['Email'];
                $_SESSION['First_name'] = $row['First_name'];

                // Check if the user is an admin or barista (you can add more roles if needed).
                if (isset($_POST['Admin'])) {
                    if ($row["Admin_rights"] == 2) {
                        $_SESSION['Admin'] = $_POST['Admin'];
                        header("Location: report.php");
                    } elseif ($row["Admin_rights"] == 1) {
                        $_SESSION['Barista'] = $_POST['Admin'];
                        header("Location: orders_display.php");
                    }
                } else {
                    header("Location: index.php");
                }
                exit();
            } else {
                // Incorrect email or password.
                header("Location: login.php?error=Incorrect email or password");
                exit();
            }
        } else {
            // Incorrect email or password.
            header("Location: login.php?error=Incorrect email or password");
            exit();
        }
    }
} else {
    header("Location: index.php");
    exit();
}
?>
