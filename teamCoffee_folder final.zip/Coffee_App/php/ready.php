<?php 

// Include the database connection file 'connect.php'.
include "connect.php";

// Start a PHP session.
session_start();

// Set error reporting to display errors during development.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the 'id' parameter is present in the URL.
if (isset($_GET['id'])) {

    // Function to validate and sanitize data.
    function validate($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    // Validate and retrieve the 'id' parameter from the URL.
    $id = validate($_GET['id']);

    // Check if 'id' is empty.
    if (empty($id)) {
        // Redirect to 'orders_display.php' with an error message.
        header("Location: orders_display.php?error=There was an error");
        exit();
    } else {
        // SQL query to select a specific order with the given 'id'.
        $sql = "SELECT * FROM Current_orders WHERE ID='$id'";

        // Execute the SQL query.
        $result = mysqli_query($conn, $sql);

        // Check if there is exactly one row in the result.
        if (mysqli_num_rows($result) === 1) {
            // Fetch the order state and set it to '2' (assuming this represents a change in order state).

            $row = mysqli_fetch_assoc($result);
            $order = $row["Order_state"];
			
            $sql = "UPDATE Current_orders SET Order_state=2 WHERE ID=$id";

            // Check if the SQL update was successful.
            if ($conn->query($sql) === TRUE) {
                // Redirect to 'orders_display.php' with a success message.
                header("Location: orders_display.php?error=Success");
            } else {
                // Redirect to 'orders_display.php' with an error message for the update.
                header("Location: orders_display.php?error=Update error occurred");
                exit();		
            }
        } else if (mysqli_num_rows($result) === 0) {
            // Redirect to 'orders_display.php' with an error message indicating the ID doesn't exist.
            header("Location: orders_display.php?error=This ID does not exist");
            exit();
        } else {
            // Redirect to 'orders_display.php' with a generic error message.
            header("Location: orders_display.php?error=There was an error");
            exit();
        }
    }
} else {
    // If 'id' is not present in the URL, redirect to 'index.php'.
    header("Location: index.php");
    exit();
}