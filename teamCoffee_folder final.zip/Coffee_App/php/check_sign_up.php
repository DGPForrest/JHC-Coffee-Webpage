<?php 
session_start(); // Start a new session or resume the existing session.
include "connect.php"; // Include the database connection file.

if (1==1) { // This condition always evaluates to true. You might want to replace it with a meaningful condition.

    function validate($data) {
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    // Retrieve and validate user registration data from the POST request.
    $fname = validate($_POST['fname']);
    $lname = validate($_POST['lname']);
    $email = validate($_POST['email']);
    $cemail = validate($_POST['confirm_email']);
    $pass = validate($_POST['password']);
    $cpass = validate($_POST['confirm_password']);

    // Check if any of the required fields are empty.
    if (empty($fname)) {
        header("Location: sign_up.php?error=First Name is required");
        exit();
    } else if (empty($lname)) {
        header("Location: sign_up.php?error=Last Name is required");
        exit();
    } else if (empty($email)) {
        header("Location: sign_up.php?error=Email is required");
        exit();
    } else if (empty($cemail)) {
        header("Location: sign_up.php?error=Confirm your email");
        exit();
    } else if (empty($pass)) {
        header("Location: sign_up.php?error=Password is required");
        exit();
    } else if (empty($cpass)) {
        header("Location: sign_up.php?error=Confirm your password");
        exit();
    } else if ($email <> $cemail) {
        header("Location: sign_up.php?error=Email's do not match&id=$id");
        exit();
    } else if ($pass <> $cpass) {
        header("Location: sign_up.php?error=Password's do not match");
        exit();
    } else {
        // Hash the user's password for secure storage.
        $options = ['cost' => 12];
        $hash = password_hash($pass, PASSWORD_BCRYPT, $options);
        
        // Check if the provided email already exists in the database.
        $sql = "SELECT Email FROM Users WHERE Email='$email'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);

        if ($email == $row['Email']) {
            header("Location: sign_up.php?error=Email already exists");
            exit();
        }

        // Insert the user's information into the database to create a new account.
        $sql = "INSERT INTO Users (First_name, Last_Name, Email, Password, Phone_number, Admin_rights, No_orders, DOB, Favourites)
                VALUES ('$fname', '$lname', '$email', '$hash', '0', '0', '0', '2000-01-01', 'none')";

        if ($conn->query($sql) === TRUE) {
            // Account created successfully. Set session variables and redirect to the index page.
            echo "Account created"; // You can remove this line (used for debugging).
            $_SESSION['Email'] = $email;
            $_SESSION['First_name'] = $fname;
            header("Location: index.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error; // You can remove this line (used for debugging).
        }
        exit();
    }
} else {
    echo "Something broke"; // You can remove this line (used for debugging).
    header("Location: index.php");
    exit();
}
?>
