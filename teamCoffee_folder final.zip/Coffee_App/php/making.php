<?php
// Include the 'connect.php' file, start a session, and set error reporting.
include "connect.php";
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the 'id' parameter is set in the GET request.
if (isset($_GET['id'])) {
    // Define a function to validate data (used for sanitizing).
    function validate($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    // Get and validate the 'id' from the GET request.
    $id = validate($_GET['id']);

    if (empty($id)) {
        // If 'id' is empty, redirect to 'orders_display.php' with an error message.
        header("Location: orders_display.php?error=There was an error");
        exit();
    } else {
        // 'id' is not empty, proceed to process the order.

        // Select the order with the given 'id' from the 'Current_orders' table.
        $sql = "SELECT * FROM Current_orders WHERE ID='$id'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {
            // If a single order with the given 'id' is found, update its 'Order_state' to 1 (Being Made).
            $row = mysqli_fetch_assoc($result);
            $order = $row["Order_state"];
            $user_id = $row["User_ID"];
            $sql = "UPDATE Current_orders SET Order_state=1 WHERE ID=$id";

            if ($conn->query($sql) === TRUE) {
                // If the update is successful, retrieve the customer's email address.

                $sql = "SELECT * FROM Users WHERE ID='$user_id'";
                $result = mysqli_query($conn, $sql);
                $row = mysqli_fetch_assoc($result);
                $email = $row["Email"];

                // Send an email notification to the customer.
                $sql = "INSERT INTO To_send (Contact_info, Type, Title, Message, Sent)
                    VALUES ('$email', 'email', 'Your order is being made!', 'Please start making your way over to pick up your order from the JHC coffee cart near the canteen.', '0')";

                if ($conn->query($sql) === TRUE) {
                    // If the email is sent successfully, redirect to 'orders_display.php' with a success message.
                    header("Location: orders_display.php?error=Success");
                } else {
                    // If there's an error while sending the email, display an error message.
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                // If there's an error during the update, redirect to 'orders_display.php' with an error message.
                header("Location: orders_display.php?error=Update error occurred");
                exit();
            }
        } else if (mysqli_num_rows($result) === 0) {
            // If no order with the given 'id' is found, redirect to 'orders_display.php' with an error message.
            header("Location: orders_display.php?error=This ID does not exist");
            exit();
        } else {
            // If there's an error, redirect to 'orders_display.php' with a generic error message.
            header("Location: orders_display.php?error=There was an error");
            exit();
        }
    }
} else {
    // If 'id' is not set in the GET request, redirect to 'index.php'.
    header("Location: index.php");
    exit();
}
