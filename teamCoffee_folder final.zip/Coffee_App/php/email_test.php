<!--------------TEST OF EMAIL SERVER----------------------------->










<?php
	
	echo "hello there";
?>

<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>301 Moved Permanently</title>
</head><body>
<h1>Moved Permanently</h1>
<p>The document has moved <a href="https://projectspace.nz/jrivyevj/Coffee_App/php/email_test.php">here</a>.</p>
<hr>
<address>Apache/2.4.41 (Ubuntu) Server at projectspace.nz Port 80</address>
</body></html>