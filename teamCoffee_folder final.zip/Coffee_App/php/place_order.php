<?php 

// Start a PHP session.
session_start(); 

// Include the 'connect.php' file to establish a database connection.
include "connect.php";

// Get the user's email from the session.
$user_email = $_SESSION['Email'];

// Always true condition for the following block, for comment purposes.

if (1 == 1) {
    // Define a validation function to clean user input data.
    function validate($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    // Validate and retrieve order time and pick-up date from the POST data.
    $order_time = validate($_POST['order_time']);
    $pick_up_date = validate($_POST['pick_up_date']);

    if (empty($order_time)){
        // Handle the case where order time is empty (optional: redirect with an error message).
        // header("Location: index.php?error=Please select a pick-up time");
        exit();
    } else if (empty($pick_up_date)){
        // Handle the case where pick-up date is empty (optional: redirect with an error message).
        // header("Location: index.php?error=Please enter a pick-up date");
        exit();
    } else {
        // SQL query to retrieve user information from the 'Users' table based on email.
        $sql = "SELECT * FROM Users WHERE Email='$user_email'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        
        // Extract user details.
        $User_Name = $row['First_name'];
        $User_ID = $row['ID'];
        $No_orders = $row['No_orders'];
        $No_orders = $No_orders + 1;

        // SQL query to retrieve items from the user's cart.
        $sql = "SELECT * FROM Cart WHERE User_ID='$User_ID'";
        $cresult = mysqli_query($conn, $sql);

        if ($cresult) {
            if ($cresult->num_rows > 0) {
                while ($crow = $cresult->fetch_assoc()) {
                    // Extract cart item details.
                    $product = $crow["Product"];
                    $extras = $crow["Extras"];
                    $comments = $crow["Comments"];
                    $size = $crow["Size"];
                    $quantity = $crow["Quantity"];
                    $cost = $crow["Cost"];
                    $cost = floatval($crow["Cost"]);
                    $quantity = $crow["Quantity"];
                    $cost = floatval($cost) * floatval($quantity);
                    $cost = money_format("%i", $cost);

                    // Insert the cart items into the 'Current_orders' table.
                    $sql = "INSERT INTO Current_orders (User_ID, Name, Products, Extras, Comments, Size, Quantity, Total_Cost, Payment_state, Order_state, Pick_up_time, Pick_up_date)
                    VALUES ('$User_ID', '$User_Name', '$product', '$extras', '$comments', '$size', '$quantity', '$cost', '0', '0', '$order_time', '$pick_up_date')";

                    if ($conn->query($sql) === TRUE) {
                        // Update the 'No_orders' in the 'Users' table.
                        $sql = "UPDATE Users SET No_orders = '$No_orders' WHERE ID=$User_ID";

                        if ($conn->query($sql) === TRUE) {
                            // Delete items from the user's cart.
                            $sql = "DELETE FROM Cart WHERE User_ID=$User_ID";

                            if (mysqli_query($conn, $sql)) {
                                echo "Record deleted successfully";
                            } else {
                                echo "Error deleting record: " . mysqli_error($conn);
                            }
                        } else {
                            echo "Error updating record: " . $conn->error;
                        }
                    }
                }
            }
        }

        // Insert a notification into the 'To_send' table for the user.
        $sql = "INSERT INTO To_send (Contact_info, Type, Title, Message, Sent)
                VALUES ('$user_email', 'email', 'Your order has been successful!', 'Please pick up your order on the $pick_up_date at $order_time from the JHC coffee cart.', '0')";

        if ($conn->query($sql) === TRUE) {
            echo "Email sent";
            header("Location: order_complete.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        exit();
    }

} else {
    echo "Something broke";
    header("Location: index.php");
    exit();
}
