<?php

// Start a session to manage user data
session_start();

// Include the "connect.php" file for database connection
include "connect.php";

// Get the user's email from the session data
$user_email = $_SESSION['Email'];

// Check if 1 is equal to 1 (this is always true, so the following code will execute)
if (1 == 1) {

    // Define a data validation function
    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    // Initialize variables for extras
    $all_extras = "";
    $extras_cost = "";
    
    // Get the selected extras from the form
    $extras = (isset($_POST['extras_chk'])) ? $_POST['extras_chk'] : array();

    // If extras are selected
    if (count($extras) > 0) {
        foreach ($extras as $extras) {
            // Concatenate selected extras into a string
            $all_extras = $extras . ' and ' . $all_extras;

            // Query the database to get the cost of each extra
            $sql = "SELECT * FROM Products WHERE Name='$extras'";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($result);

            // Calculate the cost of each extra and accumulate the total cost
            $ecost = $row["Dollars"] . '.' . $row["Cents"];
            $extras_cost = $extras_cost + $ecost;
        }
    } else {
        // If no extras are selected, set to "none"
        $extras = "none";
    }

    // Remove trailing 'and' from the concatenated extras string
    $extras = preg_replace('/\W\w+\s*(\W*)$/', '$1', $all_extras);

    // Output the extras and their total cost
    echo $extras;
    echo $extras_cost;
    
    // Validate and retrieve other form data
    $size = validate($_POST['size']);
    $quantity = validate($_POST['Quantity']);
    $comments = validate($_POST['Comments']);
    $product = validate($_POST['Product']);

    echo '<br>';
    echo $size;
    echo '<br>';
    echo $quantity;
    echo '<br>';
    echo $comments;
    echo '<br>';
    echo $product;
    echo '<br>';

    // Check for empty size, quantity, and product fields
    if (empty($size)) {
        header("Location: index.php?error=Please select a size");
        exit();
    } elseif (empty($quantity)) {
        header("Location: index.php?error=Please enter a quantity");
        exit();
    } elseif (empty($product)) {
        header("Location: index.php?error=An error occurred, please try again later");
        exit();
    } else {
        // If all fields are valid, proceed to insert data into the database
        
        // Set defaults for extras and comments if they are empty
        if (empty($extras)) {
            $extras = "none";
        }
        if (empty($comments)) {
            $comments = "none";
        }
        
        // Query the database to get user information
        $sql = "SELECT * FROM Users WHERE Email='$user_email'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        
        // Retrieve user's name and ID
        $User_Name = $row['First_name'];
        $User_ID = $row['ID'];
        
        // Query the database to get product cost
        $sql = "SELECT * FROM Products WHERE Name='$product'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        
        // Calculate the total cost, including extras
        $cost = $row["Dollars"] . '.' . $row["Cents"];
        $cost = $cost + $extras_cost;
        echo $cost;
        
        // Insert order data into the "Cart" table
        $sql = "INSERT INTO Cart (User_ID, Name, Product, Extras, Comments, Size, Quantity, Cost)
        VALUES ('$User_ID', '$User_Name', '$product', '$extras', '$comments', '$size', '$quantity', '$cost')";
        
        if ($conn->query($sql) === TRUE) {
            // If the insertion is successful, inform the user and redirect
            echo "Added to cart";
            header("Location: index.php?error=Added to cart");
        } else {
            // If there's an error in the SQL query, display the error message
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        
        // Exit the script
        exit();
    }
} else {
    // If 1 is not equal to 1 (which never happens), display an error message
    echo "Something broke";
    header("Location: index.php");
    exit();
}
