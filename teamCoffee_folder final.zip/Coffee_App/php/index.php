<!--─────────────────HOME PAGE────────────────-->

<?php include("topbit.php")?>

<?php 

session_start();

if (isset($_SESSION['Email']) && isset($_SESSION['First_name'])) {
	if (isset($_SESSION['Barista'])) {
	?>
	<form action="orders_display.php">
    	<input type="submit" class="btn btn-primary" value="View current orders" />
	</form>
	
	<?php
	}elseif (isset($_SESSION['Admin'])) {
	?>
<div class="links">
	<form action="orders_display.php">
    	<input type="submit" class="btn btn-primary" value="View current orders" />
	</form>
	<form action="report.php">
    	<input type="submit" class="btn btn-primary" value="View past orders" />
	</form>
	<form action="product.php">
    	<input type="submit" class="btn btn-primary" value="Product management" />
	</form>
</div>
	<?php
	}
 ?>

	

  <main>
    <container>
		<p>This is the main order page</p>	
	</container>

	  
	  
	  <?php if (isset($_GET['error'])) { ?>
					<p class="error"><?php echo $_GET['error']; ?></p>
					<?php } ?>

<?php 

}else{

     header("Location: login.php");
	//echo "Session not found";
     exit();

}

 ?>






<?php
	require_once 'connect.php';
	$sql = "SELECT *
		FROM Products P
		WHERE P.Type = '1'";


	$result = $conn->query($sql);
		
		
	if($result){
      	if ($result->num_rows> 0) {  
			while($row = $result->fetch_assoc()){
				$ID = $row["ID"];
				$url = "order.php";
				//echo $url;
				
				try {
  					$cents = $row["Cents"];
					if ($cents == "0"){
						$cents = "00";	
					}
				}
				catch(Exception $error) {
  					$cents = "00";
					
				}
				


					echo '<div class="product">';
						echo '<h2 class="PName">' . $row["Name"] . '</h2>';	
						echo '<p class="Description">' . $row["Description"] . '</p>';
						echo '<div class="price-box">';
							echo '<h3 class="Price">$' . $row["Dollars"] . '.' . $cents . '</h3>';	
							echo '<button class="buynow btn btn-primary" onclick="show(' . $row["ID"] . ')" id="buynow">Expand</button>';
						echo '</div>';
						echo '<form action="add_to_cart.php" id="additional_order" method="post">';
						echo '<div class="moreoptions" id="' . $row["ID"] . '" style="display: none;">';
						//extras option
							$extras = "SELECT *
								FROM Products P
								WHERE P.Type = '2'";
							
							$eresults = $conn->query($extras);
							echo '<hr>';
							
							echo '<h3>Select any extras you want</h3>';
							
							echo '<div class="extras" id="add_ons">';
							if($eresults){
								if ($eresults->num_rows> 0) {  
									while($erow = $eresults->fetch_assoc()){
				
										//echo $erow["Name"];
										//echo $erow["Dollars"];
										//echo $erow["Cents"];
										
										
										
										try {
  											$cents = $erow["Cents"];
											if ($cents == "0"){
												$cents = "00";	
											}
										}
										catch(Exception $error) {
											$cents = "00";

										}
										
										
											
										  	echo '<input type="checkbox" id="extras_chk" name="extras_chk[]" value="' . $erow["Name"] . '">';
										  	echo '<label for="extras_chk[]">' . $erow["Name"] . '  <p>$' . $erow["Dollars"] . '.' . $cents . '</p></label><br>';

									}
								}
							}
							
							echo '</div>';
							echo '<div class="extras" id="size">';
							echo '<h3>Choose a size</h3>';
							echo '<input type="radio" id="Small" name="size" value="Small" required>';
							echo '<label for="Small">Small</label><br>';
							echo '<input type="radio" id="Medium" name="size" value="Medium">';
							echo '<label for="Medium">Medium</label><br>';
							echo '<input type="radio" id="Large" name="size" value="Large">';
							echo '<label for="Large">Large</label>';
							echo '</div>';
							echo '<br>';
							echo '<div class="extras" id="quantity">';
							echo '<h3>Quantity:</h3>';
							echo '<div class="quantity">';
							echo '<button type="button" id="decrement" onclick="stepper(this,' . $row["ID"] . '' . $row["ID"] . ')"> - </button>';
							echo '<input type="number" class="quantity_counter" id="' . $row["ID"] . '' . $row["ID"] . '" name="Quantity" value="1" min="1" max="10" step="1">';
							echo '<button type="button" id="increment" onclick="stepper(this,' . $row["ID"] . '' . $row["ID"] . ')"> + </button>';
							echo '</div>';
							echo' <h3 for="Comments">Additional infomation:</h3>';
							echo '<input type="text" id="Comments" name="Comments" maxlength="255"><br><br>';
							echo '</div>';
							echo '<button type="submit" class="btn btn-primary">Add to cart</button>';
							echo '<input type="text" id="Product" name="Product" value="' . $row["Name"] . '" style="visibility: hidden; width: 1px; height: 1px;">';     
							echo '</form>';

						//Comments
						//Size
						//Quantity
					echo '</div>';
	 				echo '</div>';
					
					

				}
		}
	}
	

?>
	
				 


   </main>     
<?php include("bottombit.php") ?>

<script>
	
	
function show(ID) {
  	var x = document.getElementById(ID);
  	if (x.style.display === "none") {
    	x.style.display = "block";
  	} else {
	    x.style.display = "none";
  	}
}

	
	
	

</script>



