<?php 

session_start(); // Start a new session

include "connect.php"; // Include the connection to your database

if (1==1) { 

    function validate($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }
    
    $vemail = $_SESSION['verification_email']; // Get the email from the session
    
    $cpass = validate($_POST['cpass']); // Validate the new password from the form
    $ccpass = validate($_POST['ccpass']); // Validate the password confirmation from the form
    
    if (empty($cpass)) {
        header("Location: change_pass.php?error=Password is required"); // Redirect with an error if the password is empty
        exit();
    } else if (empty($ccpass)) {
        header("Location: change_pass.php?error=Confirm your password"); // Redirect with an error if the password confirmation is empty
        exit();
    } else if ($cpass <> $ccpass) {
        header("Location: change_pass.php?error=Passwords do not match"); // Redirect with an error if passwords don't match
        exit();
    } else {
        // Password validation and confirmation passed
        
        // Hash the new password
        $options = ['cost' => 12,];
        $hash = password_hash($cpass, PASSWORD_BCRYPT, $options);
        
        // Query the database to fetch the user's data based on their email
        $sql = "SELECT * FROM Users WHERE Email='$vemail'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        
        // Get the user's ID from the fetched data
        $id = $row['ID'];
        
        // Update the user's password in the database
        $sql = "UPDATE Users SET Password = '$hash' WHERE ID=$id";
        
        // Check if the database update was successful
        if ($conn->query($sql) === TRUE) {
            echo "Record updated successfully";
            header("Location: login.php?error=Password updated"); // Redirect with a success message
        } else {
            echo "Error updating record: " . $conn->error;
            header("Location: login.php?error=Couldn't update password"); // Redirect with an error message
        }
    }
}
?>
