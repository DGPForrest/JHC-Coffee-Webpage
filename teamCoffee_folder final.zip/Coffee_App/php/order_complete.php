<!-- Include the top part of the webpage (HTML header, navigation, etc.) -->
<?php include("topbit.php");

// Set a refresh header to redirect to the home page after 10 seconds
header("refresh:10;url=index.php");
?>

<?php 

// Start a PHP session.
session_start();

// Check if the user is logged in and has a session.
if (isset($_SESSION['Email']) && isset($_SESSION['First_name'])) {
	// Check if the user is an admin.
	if (isset($_SESSION['Admin'])) {
	?>

	<!-- Display content for admin users here, if needed -->
	<?php
	}
?>

<main>
	<!-- Display an error message if it exists in the GET parameters -->
	<?php if (isset($_GET['error'])) { ?>
		<p class="error"><?php echo $_GET['error']; ?></p>
	<?php } ?>

	<h3>Your order is successful!</h3>
	<p>An email confirmation has been sent to you.</p>
</main>

<?php include("bottombit.php"); ?>

<?php 
// Close the PHP session block
} else {
	// Redirect to the login page if the session is not found.
	header("Location: login.php");
	exit();
}
?>
