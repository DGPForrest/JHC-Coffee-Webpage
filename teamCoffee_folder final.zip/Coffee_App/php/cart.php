<!--─────────────────Cart page────────────────-->

<?php include("topbit.php")?>

<?php 

session_start();

if (isset($_SESSION['Email']) && isset($_SESSION['First_name'])) {
	if (isset($_SESSION['Barista'])) {
	?>
	<form action="orders_display.php">
    	<input type="submit" class="btn btn-primary" value="View current orders" />
	</form>
	
	<?php
	}elseif (isset($_SESSION['Admin'])) {
	?>
<div class="links">
	<form action="orders_display.php">
    	<input type="submit" class="btn btn-primary" value="View current orders" />
	</form>
	<form action="report.php">
    	<input type="submit" class="btn btn-primary" value="View past orders" />
	</form>
</div>
	<?php
	}
 ?>

	

  <main>
    <container>
	</container>

	  
	  
	  <?php if (isset($_GET['error'])) { ?>
					<p class="error"><?php echo $_GET['error']; ?></p>
					<?php } ?>

<?php 

}else{

     header("Location: login.php");
	//echo "Session not found";
     exit();

}

 ?>









<?php
	require_once 'connect.php';
	  
	ini_set('display_errors', 0);
	  
	$total_cost = "";
	date_default_timezone_set("Pacific/Auckland");
	$date = date("Y-m-d");   
	  
	$user_email = $_SESSION['Email'];
	  
	$csql = "SELECT * FROM Users WHERE Email='$user_email'";

    $cresult = mysqli_query($conn, $csql);

    $crow = mysqli_fetch_assoc($cresult);
	  
	 $ID = $crow["ID"];
	  
	$sql = "SELECT *
		FROM Cart Po WHERE User_ID='$ID'";


	$result = $conn->query($sql);
		
	echo'<div id="cart">';
	if($result){
      	if ($result->num_rows> 0) {  
			while($row = $result->fetch_assoc()){
				$ID = $row["ID"];
				//echo $url;
				$size = "Not defined";
				if ($row["Size"] == "1"){
					$size = "Small";
				}else if ($row["Size"] == "2"){
					$size = "Medium";
				}else if ($row["Size"] == "3"){
					$size = "Large";
				}
				$cost = floatval($row["Cost"]);
				$quantity = $row["Quantity"];
				//$total_cost = $total_cost + floatval($cost);
				$cost = floatval($cost) * floatval($quantity);
				$cost = money_format("%i", $cost);
				$totalcost = floatval($totalcost) + floatval($cost);
				$totalcost = money_format("%i", $totalcost);				
					
					

					echo '<div class="item product">';
						echo '<h2 class="Cart_Product">' . $row["Product"] . '</h2>';
						
						if ($row["Extras"] <> "none"){
							echo '<p class="Extras">Extras: ' . $row["Extras"] . '</p>';
						}
						echo '<p class="Size">Size: ' . $row["Size"] . '</p>';
						echo '<p class="CQuantity">Quantity: ' . $row["Quantity"] . '</p>';
						if ($row["Comments"] <> "none"){
							echo '<p class="Comments">Additional infomation: ' . $row["Comments"] . '</p>';
						}
						echo '<p class="Cost">Cost: $' . $cost . '</p>';
						echo '<form action="delete_cart.php?id=' . $row["ID"] . '" method="post">';
							echo '<input type="submit" class="btn btn-primary" value="Remove" />';
							echo '<input type="text" id="Delete_cart" name="Delete_cart" value="' . $row["ID"] . '" style="visibility: hidden; width: 1px; height: 1px;">';     
						echo '</form>';
						
					

	 				echo '</div>';
			}
					echo '<form action="place_order.php" method="post" id="order_submit">';
						echo '<label for="pick_up_date">Pick up date:</label>';
						echo '<input type="date" name="pick_up_date" id="pick_up_date" min="' . $date . '" required>';
						echo '<br>';
						echo '<input type="radio" id="interval" name="order_time" value="interval" required>';
						echo '<label for="interval">Interval</label>';
						echo '<input type="radio" id="lunch" name="order_time" value="lunch">';
						echo '<label for="lunch">Lunch</label><br>';
						echo '<label>Total cost: $' . $totalcost . '</label><br>';
						echo '<input type="submit" class="btn btn-primary" value="Submit order" />';
					echo '</form>';

					

				
		}else{
			echo '<p>There is nothing in your cart</p>';
			
		}
		
		
		
	
		
		
		
		
		
		
		
		
		
		
	}
	echo'</div>';
	  


?>

	  
	





	












   </main>     
<?php include("bottombit.php") ?>
