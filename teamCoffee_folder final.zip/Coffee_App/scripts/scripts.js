
/*


var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
};





*/





function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

//---------increasement button
function stepper(btn,IDvalue){
	const myInput = document.getElementById(IDvalue);
	let id = btn.getAttribute("id");
	let min = myInput.getAttribute("min");
	let max = myInput.getAttribute("max");
	let step = myInput.getAttribute("step");
	let val = myInput.getAttribute("value");
	let calcStep = (id == "increment") ? (step*1) :
	(step * -1);
	let newValue = parseInt(val) + calcStep;
	
	if(newValue >= min && newValue <= max){
		
		myInput.setAttribute("value", newValue);
	}
}


//---------- Search Bar active ----

//Getting value from "ajax.php".
function fill(Value) {
   //Assigning value to "search" div in "search.php" file.
   $('#email').val(Value);
   //Hiding "display" div in "search.php" file.
   $('#admin').hide();
};

$(document).ready(function() {
   //On pressing a key on "Search box" in "search.php" file. This function will be called.
   $("#email").keyup(function() {
       //Assigning search box value to javascript variable named as "name".
       var email = $('#email').val();
       //Validating, if "name" is empty.
       if (email == "") {
           //Assigning empty value to "display" div in "search.php" file.
       }
       //If name is not empty.
       else {
           //AJAX is called.
           $.ajax({
               //AJAX type is "Post".
               type: "POST",
               //Data will be sent to "ajax.php".
               url: "ajax.php",
               //Data, that will be sent to "ajax.php".
               data: {
                   //Assigning value of "name" into "search" variable.
                   email: email
               },
               //If result found, this funtion will be called.
               success: function(html) {
                   //Assigning result to "display" div in "search.php" file.
                   $("#admin").html(html).show();
               }
           });
       }
   });
});


